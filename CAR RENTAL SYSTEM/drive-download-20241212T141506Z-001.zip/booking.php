<?php
 include 'db.php';
 $query = "SELECT * FROM cars";
 $result = mysqli_query($conn, $query);
 $cars = mysqli_fetch_all($result, MYSQLI_ASSOC);
 if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    $persons = mysqli_real_escape_string($conn, $_POST['persons']);
    $car_id = mysqli_real_escape_string($conn, $_POST['car_id']);
    $pickup_location = mysqli_real_escape_string($conn, $_POST['pickup_location']);
    $pickup_date = mysqli_real_escape_string($conn, $_POST['pickup_date']);
    $pickup_time = mysqli_real_escape_string($conn, $_POST['pickup_time']);
    $return_date = mysqli_real_escape_string($conn, $_POST['return_date']);
    
    $sql = "INSERT INTO bookings (name, phone, persons, car_id, pickup_location, pickup_date, pickup_time, return_date) 
            VALUES ('$name', '$phone', '$persons', '$car_id', '$pickup_location', '$pickup_date', '$pickup_time', '$return_date')";
    
    if (mysqli_query($conn, $sql)) {
        $booking_id = mysqli_insert_id($conn);
        header("Location: process_payment.php?booking_id=" . $booking_id);
        exit();
    } else {
        echo "<script>alert('Error: " . mysqli_error($conn) . "');</script>";
    }

}
$car_id = isset($_GET['car_id']) ? (int)$_GET['car_id'] : 0;

$query = "SELECT id, name, price_per_day, model_year, brand, passengers, transmission, image_url, category 
         FROM cars 
         WHERE id = ?";
         
$stmt = mysqli_prepare($conn, $query);
mysqli_stmt_bind_param($stmt, "i", $car_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$car = mysqli_fetch_assoc($result);

if (!$car) {
    header("Location: cars2.php");
    exit();
}
function validateBookingData($data) {
    $errors = [];
    
    // Validate date ranges
    $pickup = strtotime($data['pickup_date']);
    $return = strtotime($data['return_date']);
    $today = strtotime(date('Y-m-d'));
    
    if ($pickup < $today) {
        $errors[] = "Pickup date cannot be in the past";
    }
    
    if ($return < $pickup) {
        $errors[] = "Return date must be after pickup date";
    }
    
    // Validate phone number
    if (!preg_match("/^[0-9]{10}$/", $data['phone'])) {
        $errors[] = "Invalid phone number format";
    }
    
    return $errors;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="/style/booking.css">
    <title>Booking-CarRental Form</title>
</head>
<div class="col-md-4 mb-3">
    <input type="hidden" name="car_id" value="<?php echo htmlspecialchars($car['id']); ?>">
    <!-- This hidden field will store the car ID -->
</div>
<style>
       /* General Reset */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

/* Base Styles */
body {
    font-family: 'Arial', sans-serif;
    background-color: #f5f5f5;
    padding: 2rem;
    padding-top: 100px;
    min-height: 100vh;
    overflow-y: auto;
    margin: 0;
}
.search-container {
    display: flex;
    align-items: center;
    position: relative;
}

.search-input {
    padding: 8px 32px 8px 12px;
    border: 1px solid #ddd;
    border-radius: 20px;
    outline: none;
    transition: all 0.3s ease;
}

.search-input:focus {
    border-color: #007bff;
    box-shadow: 0 0 5px rgba(0,123,255,0.3);
}

.search-icon {
    position: absolute;
    right: 10px;
    cursor: pointer;
    color: #666;
}

.search-icon:hover {
    color: #007bff;
}

/* Container Styles */
.container {
   
    padding: 20px 10px;
    background-color: #ffffff;
    border-radius: 25px;  /* Slightly larger radius for modern look */
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);  /* Softer, more spread shadow */
    margin: 40px auto;  /* Center container and add vertical margin */
    backdrop-filter: blur(10px);  /* Adds frosted glass effect */
    border: 1px solid rgba(255, 255, 255, 0.1);  /* Subtle border */
    transition: transform 0.3s ease, box-shadow 0.3s ease;  /* Smooth hover effect */
    flex-direction: column;
    align-items: center;
    justify-content: center;

}
.container:hover {
    transform: translateY(-5px);
    box-shadow: 0 15px 35px rgba(0, 0, 0, 0.12);
}
.container h1 {
    text-align: center;
    color: #333;
    margin-bottom: 40px;
    font-size: 2.5rem;
    font-weight: 600;
}

form {
    width: 200%;
    max-width: 1000px;
    margin: 0 auto;
}
.form-control {
    height: 50px;
    border-radius: 8px;
    border: 1px solid #ddd;
    padding: 10px 15px;
    font-size: 16px;
    transition: all 0.3s ease;
}

.form-control:focus {
    border-color: #ff0000;
    box-shadow: 0 0 0 0.2rem rgba(255, 0, 0, 0.1);
    outline: none;
}

select.form-control {
    appearance: none;
    background-image: url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3e%3cpolyline points='6 9 12 15 18 9'%3e%3c/polyline%3e%3c/svg%3e");
    background-repeat: no-repeat;
    background-position: right 15px center;
    background-size: 15px;
}

/* Button Styles */
.btn-danger {
    height: 50px;
    background-color: #ff0000;
    border: none;
    font-weight: 600;
    font-size: 16px;
    text-transform: uppercase;
    letter-spacing: 1px;
    transition: all 0.3s ease;
}

.btn-danger:hover {
    background-color: #cc0000;
    transform: translateY(-2px);
}

.book-btn, .book-now-btn {
    background-color: #ff0000;
    color: white;
    padding: 0.5rem 1.5rem;
    border-radius: 5px;
    text-decoration: none;
    transition: background-color 0.3s ease;
}

.book-btn:hover, .book-now-btn:hover {
    background-color: #cc0000;
}

/* Navigation */
.navbar {
    background-color: rgba(0, 0, 0, 0.8);
    padding: 15px 30px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    z-index: 1000;
    width: 100%;
}

.logo {
    display: flex;
    align-items: center;
}

.logo span:first-child {
    color: #ff0000;
    font-weight: bold;
    font-size: 24px;
}

.logo span:last-child {
    color: white;
    font-weight: bold;
    font-size: 24px;
}

.nav-links {
    display: flex;
    gap: 30px;
    align-items: center;
}

.nav-links a {
    color: white;
    text-decoration: none;
    font-size: 16px;
    transition: color 0.3s ease;
}

.nav-links a:hover {
    color: #ff0000;
}

.nav-links a.active {
    color: #ff0000;
}

/* Car Card Styles */
.car-card {
    width: 100%;
    max-width: 800px; 
    margin: 20px auto;
    text-align: left;
}
.car-card img {
    width: 100%;
    height: 200px;
    object-fit: contain; 
    object-position: center;
    transition: all 0.3s ease; 
}

.car-card:hover {
    transform: translateY(-5px);
}

.car-image img {
    width: 100%;
    height: 200px;
    object-fit: contain; 
    border-radius: 10px;
    background-color: #f5f5f5; 
}

.car-info {
    text-align: center;
    
}

.car-info h3 {
    font-size: 1.5rem;
    color: #1a1a1a;
    margin-bottom: 1rem;
    font-weight: 900;
}
.car-details-icons {
    display: flex;
    gap: 20px;
    flex-wrap: wrap;
    margin-top: 15px;
}

.detail-item {
    display: flex;
    align-items: center;
    gap: 8px;
    color: #666;
}

.detail-item i {
    color: #ff0000;
    font-size: 16px;
    width: 20px;
    text-align: center;
}

.detail-item span {
    font-size: 14px;
    white-space: nowrap;
}

/* Price and Details */
.price-book {
    display: flex;
    flex-wrap: each;
    justify-content: center;
    gap: 2rem;
    font-weight: bolder;
}

.price-book p {
    margin: 0;
    text-align: center;
}

.price-book i {
    display: flex;
    align-items: center;
    gap: 8px;
    color: #ff0000;
    font-size: 16px;
    margin-bottom: 10px;
}


.price {
    font-size: 1.25rem;
    font-weight: bold;
    color: #1a1a1a;
}
.price-book i:hover {
    transform: translateY(-2px);
    transition: transform 0.2s ease;
}
.fas, .far {
    min-width: 20px;
    text-align: center;
}

/* Responsive Design */
@media (max-width: 768px) {
    body {
        padding-top: 80px;
        padding: 1rem;
    }
    
    .container {
        padding: 20px 15px;
    }
    
    .container h1 {
        font-size: 2rem;
        margin-bottom: 30px;
    }
    
    .car-grid {
        grid-template-columns: 1fr;
    }
    
    .car-details {
        grid-template-columns: 1fr;
    }
}

@media (max-width: 480px) {
    .price-book {
        grid-template-columns: 1fr;
    }
    
    .book-btn {
        width: 100%;
        text-align: center;
    }
}


.close-btn {
    position: absolute;
    top: 5px;
    right: 20px;
    font-size: 20px;
    color: red;
    padding: 0px 2px;
}


</style>
<body>
<nav class="navbar">
    <div class="logo">
        <span>MTT</span><span>CarRental</span>
    </div>
    <div class="nav-links">
        <a href="form2.php">Home</a>
        <a href="cars2.php">Cars</a>
        <a href="booking.php" class="active">Booking</a>
        <a href="my_bookings.php">My Bookings</a>
        <a href="#">Contact us</a>
        <div class="search-container">
            <input type="text" class="search-input" placeholder="Search cars...">
            <i class="search-icon fas fa-search"></i>
        </div>
        <a href="dashboard.php" type="submit" class="book-btn">Dashboard</a>
    </div>
<div class="container mt-5">
    <a class="close-btn" type="button" onclick="window.location.href='cars2.php'">X</a>
    <h1>Rent Your Best Cars here.</h1>
    <form method="POST" action="">
        <div class="row">
            <div class="col-md-4 mb-3">
                <input type="text" name="name" class="form-control" placeholder="Your name" required>
            </div>
            <div class="col-md-4 mb-3">
                <input type="tel" name="phone" class="form-control" placeholder="Phone number" required>
            </div>
            <div class="col-md-4 mb-3">
                <select name="persons" class="form-control" required>
                    <option value="">How many Person</option>
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                    <option value="4">4</option>
                    <option value="5">5</option>
                </select>
            </div>
        </div>
        
        
        <div class="row">
            <div class="col-md-4 mb-3">
                <input type="text" name="pickup_location" class="form-control" placeholder="Pick up Location" required>
            </div>
            <div class="col-md-4 mb-3">
                <input type="date" name="pickup_date" class="form-control" placeholder="Pick up Date" required>
            </div>
        </div>
        
        <div class="row">
            <div class="col-md-4 mb-3">
                <input type="time" name="pickup_time" class="form-control" placeholder="Pick up Time" required>
            </div>
            <div class="col-md-4 mb-3">
                <input type="date" name="return_date" class="form-control" placeholder="Return Date" required>
            </div>
            <div class="col-md-4 mb-3">
                <button type="submit" class="btn btn-danger btn-block">Book Now</button>
            </div>
        </div>
        <div class="car-card">
            <img src="<?php echo htmlspecialchars($car['image_url']); ?>"
                 alt="<?php echo htmlspecialchars($car['name']); ?>"
                 onerror="this.src='images/default-car.jpg'"
                 class="car-image">
            <div class="car-info">
                <div class="car-title">
                    <h3><?php echo htmlspecialchars($car['name']); ?></h3>
                </div>
                <div class="price-book">
                    <i class="fas fa-peso-sign">
                        <p>Price per day: ₱<?php echo htmlspecialchars($car['price_per_day']); ?></p>
                    </i>
                    <i class="far fa-calendar">
                        <p>Model Year: <?php echo htmlspecialchars($car['model_year']); ?></p>
                    </i>
                    <i class="fas fa-car">  
                        <p>Brand: <?php echo htmlspecialchars($car['brand']); ?></p>
                    </i>
                    <i class="fas fa-users">
                        <p>Passengers: <?php echo htmlspecialchars($car['passengers']); ?> Person</p>
                    </i>
                    <i class="fas fa-cog">
                        <p>Transmission: <?php echo htmlspecialchars($car['transmission']); ?></p>
                    </i>
                </div>
            </div>
        </div>
    </form>
</div>
    </div>
    <script>
    document.querySelector('.search-input').addEventListener('input', function(e) {
        const searchTerm = e.target.value.toLowerCase();
        const cars = document.querySelectorAll('.car-card');
        
        cars.forEach(car => {
            const carName = car.querySelector('h3').textContent.toLowerCase();
            const carBrand = car.querySelector('.fas.fa-car').nextElementSibling.textContent.toLowerCase();
            const carYear = car.querySelector('.far.fa-calendar').nextElementSibling.textContent.toLowerCase();
            const carTransmission = car.querySelector('.fas.fa-cog').nextElementSibling.textContent.toLowerCase();
            
            if (carName.includes(searchTerm) || 
                carBrand.includes(searchTerm) || 
                carYear.includes(searchTerm) || 
                carTransmission.includes(searchTerm)) {
                car.style.display = '';
            } else {
                car.style.display = 'none';
            }
        });
    });
</script>
    </body>
</html>