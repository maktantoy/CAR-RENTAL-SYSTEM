<?php
session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['is_admin'] !== true) {
    header("Location: login.php");
    exit();
}

include "db.php";

// Handle status updates if submitted
if (isset($_POST['booking_id']) && isset($_POST['status'])) {
    $update_sql = "UPDATE bookings SET status = ? WHERE id = ?";
    $stmt = $conn->prepare($update_sql);
    if ($stmt === false) {
        die("Error preparing update query: " . $conn->error);
    }
    $stmt->bind_param("si", $_POST['status'], $_POST['booking_id']);
    $stmt->execute();
}


$bookings_sql = "
    SELECT 
        b.*,
        b.name as user_name,
        c.name as car_name,
        c.price_per_day,
        DATEDIFF(b.return_date, b.pickup_date) as days,
        CASE 
            WHEN c.price_per_day IS NOT NULL AND c.price_per_day > 0 THEN 
                DATEDIFF(b.return_date, b.pickup_date) * c.price_per_day
            ELSE 0 
        END as total_price
    FROM bookings b 
    LEFT JOIN cars c ON b.car_id = c.id 
    ORDER BY b.booking_date DESC";

// Add debugging
$stmt = $conn->prepare($bookings_sql);
if ($stmt === false) {
    die("Error preparing bookings query: " . $conn->error);
}

if (!$stmt->execute()) {
    die("Error executing query: " . $stmt->error);
}

$bookings = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Debug output
echo "<!-- Number of bookings found: " . count($bookings) . " -->";
if (count($bookings) === 0) {
    // Let's check each table separately
    $check_bookings = $conn->query("SELECT COUNT(*) as count FROM bookings");
    $check_users = $conn->query("SELECT COUNT(*) as count FROM users");
    $check_cars = $conn->query("SELECT COUNT(*) as count FROM cars");
    
    echo "<!-- 
    Bookings count: " . $check_bookings->fetch_assoc()['count'] . "
    Users count: " . $check_users->fetch_assoc()['count'] . "
    Cars count: " . $check_cars->fetch_assoc()['count'] . "
    -->";
    
    // Let's also see some sample data
    $sample_booking = $conn->query("SELECT * FROM bookings LIMIT 1");
    $sample_user = $conn->query("SELECT * FROM users LIMIT 1");
    if ($sample_booking && $sample_user) {
        $booking_data = $sample_booking->fetch_assoc();
        $user_data = $sample_user->fetch_assoc();
        echo "<!-- 
        Sample booking name: " . ($booking_data ? $booking_data['name'] : 'none') . "
        Sample user name: " . ($user_data ? $user_data['name'] : 'none') . "
        -->";
    }
}

// Add this debug query to see what's in your cars table
$check_cars = $conn->query("SELECT * FROM cars LIMIT 1");
if ($check_cars) {
    $car_data = $check_cars->fetch_assoc();
    echo "<!-- Car Details:
    ID: " . ($car_data['id'] ?? 'N/A') . "
    Name: " . ($car_data['name'] ?? 'N/A') . "
    Model: " . ($car_data['model'] ?? 'N/A') . "
    Price per day: " . ($car_data['price_per_day'] ?? 'N/A') . "
    Status: " . ($car_data['status'] ?? 'N/A') . "
    -->";
}

// After executing the query, add this debug output
echo "<!-- 
Query executed: {$bookings_sql}
Number of bookings: " . count($bookings) . "
Sample booking data: ";
if (!empty($bookings)) {
    print_r($bookings[0]);
}
echo " -->";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Bookings - Car Rental</title>
    <link rel="stylesheet" href="style/dashboard.css">
    <link rel="stylesheet" href="style/manage_bookings.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<style>
    .bookings-filters {
    margin-bottom: 20px;
    display: flex;
    gap: 15px;
}

.bookings-filters input,
.bookings-filters select {
    padding: 8px 12px;
    border: 1px solid #ddd;
    border-radius: 4px;
    font-size: 14px;
}

.bookings-filters input {
    flex: 1;
    min-width: 200px;
}

.bookings-table {
    width: 100%;
    border-collapse: collapse;
    background: white;
    box-shadow: 0 1px 3px rgba(0,0,0,0.1);
}

.bookings-table th,
.bookings-table td {
    padding: 12px 15px;
    text-align: left;
    border-bottom: 1px solid #eee;
}

.bookings-table th {
    background-color: #f8f9fa;
    font-weight: 600;
}

.status-select {
    padding: 5px 10px;
    border-radius: 4px;
    border: 1px solid #ddd;
}

.actions {
    display: flex;
    gap: 10px;
}

.action-btn {
    background: none;
    border: none;
    cursor: pointer;
    color: #666;
    transition: color 0.3s;
}

.action-btn:hover {
    color: #dc3545;
}

.action-btn.delete:hover {
    color: #dc3545;
}

/* Status colors */
.status-select option[value="Pending"] {
    color: #856404;
}

.status-select option[value="Confirmed"] {
    color: #155724;
}

.status-select option[value="Completed"] {
    color: #004085;
}

.status-select option[value="Cancelled"] {
    color: #721c24;
}
</style>
<body>
    <div class="dashboard-container">
        <!-- Replace the include with direct sidebar code -->
        <div class="sidebar">
            <div class="user-info">
                <h3>Admin Panel</h3>
                <p><?php echo htmlspecialchars($_SESSION['email']); ?></p>
            </div>
            
            <a href="dashboard.php" class="menu-item">
                <i class="fas fa-home"></i> Dashboard
            </a>
            <a href="manage_users.php" class="menu-item">
                <i class="fas fa-users"></i> Manage Users
            </a>
            <a href="manage_cars.php" class="menu-item">
                <i class="fas fa-car"></i> Manage Cars
            </a>
            <a href="manage_bookings.php" class="menu-item active">
                <i class="fas fa-calendar-check"></i> Manage Bookings
            </a>
            <a href="reports.php" class="menu-item">
                <i class="fas fa-chart-bar"></i> Reports
            </a>
            <a href="settings.php" class="menu-item">
                <i class="fas fa-cog"></i> Settings
            </a>
            <form action="logout.php" method="POST" style="margin-top: auto;">
                <button type="submit" class="menu-item" style="width: 100%; text-align: left; border: none; background: none; color: inherit;">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </button>
            </form>
        </div>
        
        <div class="main-content">
            <h1>Manage Bookings</h1>
            
            <div class="bookings-filters">
                <input type="text" id="searchInput" placeholder="Search bookings...">
                <select id="statusFilter">
                    <option value="">All Statuses</option>
                    <option value="Pending">Pending</option>
                    <option value="Confirmed">Confirmed</option>
                    <option value="Completed">Completed</option>
                    <option value="Cancelled">Cancelled</option>
                </select>
            </div>

            <table class="bookings-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>User</th>
                        <th>Car</th>
                        <th>Pickup Date</th>
                        <th>Return Date</th>
                        <th>Total Price</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($bookings as $booking): ?>
                    <tr>
                        <td>#<?php echo htmlspecialchars($booking['id']); ?></td>
                        <td><?php echo htmlspecialchars($booking['user_name']); ?></td>
                        <td><?php echo htmlspecialchars($booking['car_name']); ?></td>
                        <td><?php echo date('M d, Y', strtotime($booking['pickup_date'])); ?></td>
                        <td><?php echo date('M d, Y', strtotime($booking['return_date'])); ?></td>
                        <td>₱<?php echo number_format($booking['total_price'], 2); ?></td>
                        <td>
                            <select class="status-select" onchange="updateStatus(<?php echo $booking['id']; ?>, this.value)">
                                <option value="Pending" <?php echo $booking['status'] == 'Pending' ? 'selected' : ''; ?>>Pending</option>
                                <option value="Confirmed" <?php echo $booking['status'] == 'Confirmed' ? 'selected' : ''; ?>>Confirmed</option>
                                <option value="Completed" <?php echo $booking['status'] == 'Completed' ? 'selected' : ''; ?>>Completed</option>
                                <option value="Cancelled" <?php echo $booking['status'] == 'Cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                            </select>
                        </td>
                        <td class="actions">
                            <a href="view_booking.php?id=<?php echo $booking['id']; ?>" class="action-btn" title="View Details">
                                <i class="fas fa-eye"></i>
                            </a>
                            <a href="edit_booking.php?id=<?php echo $booking['id']; ?>" class="action-btn" title="Edit">
                                <i class="fas fa-edit"></i>
                            </a>
                            <button onclick="deleteBooking(<?php echo $booking['id']; ?>)" class="action-btn delete" title="Delete">
                                <i class="fas fa-trash"></i>
                            </button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <script>
    function updateStatus(bookingId, status) {
        const formData = new FormData();
        formData.append('booking_id', bookingId);
        formData.append('status', status);

        fetch('manage_bookings.php', {
            method: 'POST',
            body: formData
        });
    }

    function deleteBooking(bookingId) {
        if (confirm('Are you sure you want to delete this booking?')) {
            window.location.href = `delete_booking.php?id=${bookingId}`;
        }
    }

    // Search and filter functionality
    document.getElementById('searchInput').addEventListener('input', filterBookings);
    document.getElementById('statusFilter').addEventListener('change', filterBookings);

    function filterBookings() {
        const searchTerm = document.getElementById('searchInput').value.toLowerCase();
        const statusFilter = document.getElementById('statusFilter').value;
        const rows = document.querySelectorAll('.bookings-table tbody tr');

        rows.forEach(row => {
            const text = row.textContent.toLowerCase();
            const status = row.querySelector('.status-select').value;
            const matchesSearch = text.includes(searchTerm);
            const matchesStatus = !statusFilter || status === statusFilter;
            row.style.display = matchesSearch && matchesStatus ? '' : 'none';
        });
    }
    </script>
</body>
</html> 