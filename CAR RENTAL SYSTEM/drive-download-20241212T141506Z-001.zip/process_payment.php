<?php
session_start();
include "db.php"; // Database connection

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_id = $_SESSION['user_id']; // Assuming user is logged in
    $amount = $_POST['amount'];

    // Insert payment into the database
    $stmt = $conn->prepare("INSERT INTO payments (user_id, amount) VALUES (?, ?)");
    $stmt->bind_param("id", $user_id, $amount);
    
    if ($stmt->execute()) {
        // Redirect to GCash payment gateway (this is a placeholder)
        header("Location: https://gcash.com/payment?amount=$amount");
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }
}
?> 
<!-- payment.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment</title>
    <link rel="stylesheet" href="style/payment.css">
</head>
<style>
    .payment-container {
    max-width: 400px;
    margin: 0 auto;
    padding: 20px;
    border: 1px solid #ccc;
    border-radius: 10px;
    background-color: #f9f9f9;
}

h1 {
    text-align: center;
}

label {
    display: block;
    margin-bottom: 5px;
}

input {
    width: 100%;
    padding: 10px;
    margin-bottom: 20px;
    border: 1px solid #ccc;
    border-radius: 5px;
}

button {
    width: 100%;
    padding: 10px;
    background-color: #007bff;
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
}

button:hover {
    background-color: #0056b3;
}
</style>
<body>
    <div class="payment-container">
        <h1>Make a Payment</h1>
        <form id="paymentForm" method="POST" action="process_payment.php">
            <label for="amount">Amount (₱):</label>
            <input type="number" id="amount" name="amount" required>
            <button type="submit">Pay with GCash</button>
        </form>
    </div>
    <script>
        document.getElementById('paymentForm').addEventListener('submit', function(event) {
            const amount = document.getElementById('amount').value;
            if (amount <= 0) {
                alert('Please enter a valid amount.');
                event.preventDefault();
            }
        });
    </script>
</body>
</html>